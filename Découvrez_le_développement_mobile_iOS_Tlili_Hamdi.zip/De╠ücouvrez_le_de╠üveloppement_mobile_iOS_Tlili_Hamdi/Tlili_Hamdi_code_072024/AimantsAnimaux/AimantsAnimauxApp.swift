//
//  AimantsAnimauxApp.swift
//  AimantsAnimaux
//
//  Created by HTLILI on 17/07/2024.
//

import SwiftUI

@main
struct AimantsAnimauxApp: App {
    var body: some Scene {
        WindowGroup {
            AnimalsListView()
        }
    }
}
