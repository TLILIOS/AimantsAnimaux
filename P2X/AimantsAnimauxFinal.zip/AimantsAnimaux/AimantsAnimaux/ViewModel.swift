//
//  Model.swift
//  AimantsAnimaux
//
//  Created by Amandine Cousin on 12/10/2023.
//

import Foundation
