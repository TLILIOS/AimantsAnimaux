//
//  ContentView.swift
//  AimantsAnimaux
//
//  Created by Amandine Cousin on 04/10/2023.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        VStack {
            Text("Hello, world!")
        }
        .padding()
    }
}

#Preview {
    ContentView()
}
